export default function Info() {
  return (
    <>
      <header>
        <img src="./components/image/penkek.png" />
        <section className="info-container">
          <h2>Maryam M.</h2>
          <p className="info-job">Full-Stack Developer</p>
          <small className="info-link">
            <a href="https://mrymmhmdportfolio.vercel.app/">
              mrymmhmdportfolio.vercel.app
            </a>
          </small>
        </section>
      </header>
    </>
  );
}
