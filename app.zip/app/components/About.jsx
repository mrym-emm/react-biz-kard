export default function About() {
  return <h1>Info goes here</h1>;
}
