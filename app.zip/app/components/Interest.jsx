export default function Interest() {
  return <h1>Interest goes here</h1>;
}
